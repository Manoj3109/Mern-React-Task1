import As from "./components/As-1"
import './App.css';

function App() {
  return (
    <div>
      <As/>
    </div>
  );
}

export default App;
